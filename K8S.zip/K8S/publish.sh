#!/bin/sh

while [ ! -f "/opt/bin/kubectl" ]; do
    echo "File not found. Waiting..." >> /home/core/status.log
    sleep 0.1
done

echo "File found. Continue with the rest of the script." >> /home/core/status.log



cd manifests && /opt/bin/kubectl apply -f .