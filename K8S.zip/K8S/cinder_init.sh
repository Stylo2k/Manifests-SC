#!/bin/sh
echo "installing cinder"

# if cloud.conf is not present, create it
echo "Checking for cloud.conf"

if [ ! -f cinder/cloud.conf ]; then
  if [ ! -f cinder/cloud.conf.example ]; then
    echo "creating cloud.conf.example"
    echo "\
[Global]
auth-url=https://hb-openstack.hpc.rug.nl:5000/v3
#Tip: You can also use Application Credential ID and Secret in place of username, password, tenant-id, and domain-id.
application-credential-id=<> # Application Credential ID
application-credential-secret=<> # Application Credential Secret
user-id=<> # User ID
region=RegionOne
" > cinder/cloud.conf
    echo "cloud.conf created, please fill in the correct values and run this script again"
    exit 1
  else
    echo "copying cloud.conf.example to cloud.conf"
    cp cinder/cloud.conf.example cinder/cloud.conf
  fi
fi

chown -R core:core cinder

mkdir -p /etc/kubernetes
cp cinder/cloud.conf /etc/kubernetes/cloud.conf

echo "creating secret"

echo "\
kind: Secret
apiVersion: v1
metadata:
  name: cloud-config
  namespace: kube-system
data:
  cloud.conf: $(base64 -w 0 /etc/kubernetes/cloud.conf)
" > cinder/cloud-config.yaml

echo "applying secret"

/opt/bin/kubectl apply -f cinder/cloud-config.yaml


/opt/bin/kubectl apply -f https://raw.githubusercontent.com/kubernetes/cloud-provider-openstack/master/manifests/controller-manager/cloud-controller-manager-roles.yaml
/opt/bin/kubectl apply -f https://raw.githubusercontent.com/kubernetes/cloud-provider-openstack/master/manifests/controller-manager/cloud-controller-manager-role-bindings.yaml
/opt/bin/kubectl apply -f https://raw.githubusercontent.com/kubernetes/cloud-provider-openstack/master/manifests/controller-manager/openstack-cloud-controller-manager-ds.yaml

/usr/bin/git clone https://github.com/kubernetes/cloud-provider-openstack 
cd cloud-provider-openstack
/usr/bin/git checkout tags/v1.24.2

rm manifests/cinder-csi-plugin/csi-secret-cinderplugin.yaml

/opt/bin/kubectl -f manifests/cinder-csi-plugin/ apply

cd ..

# create a storage class with the name "StorageClass"

if [ ! -f cinder/storage-class.yaml ]; then
    echo "creating storage-class.yaml"
    echo "\
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: storage-class
  annotations:
    storageclass.kubernetes.io/is-default-class: \"true\"
  labels:
    kubernetes.io/cluster-service: \"true\"
    addonmanager.kubernetes.io/mode: EnsureExists
provisioner: cinder.csi.openstack.org
parameters:
  availability: nova
allowVolumeExpansion: true
volumeBindingMode: Immediate
" > cinder/storage-class.yaml
fi

echo "applying StorageClass"

/opt/bin/kubectl apply -f cinder/storage-class.yaml
